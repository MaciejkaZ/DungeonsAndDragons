from characterABC import CharacterABC


class Mage(CharacterABC):

    def __init__(self, name, hp, strength, intelligence, damage):
        super().__init__(name, hp, strength, intelligence)
        self.damage = damage

    def attack(self):
        return 3 * self.intelligence

    def defend(self, damage):
        damage = damage - self.intelligence
        if damage > 0:
            hp = self.hp - damage
            if hp >= 0:
                self.hp = hp
            else:
                self.hp = 0
        else:
            return
