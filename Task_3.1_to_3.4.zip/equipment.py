class Equipment():
    def __init__(self, equip_name, bonus_hp, bonus_strength, bonus_intelligence):
        self.equip_name = equip_name
        self.bonus_hp = bonus_hp
        self.bonus_intelligence = bonus_intelligence
        self.bonus_strength = bonus_strength



