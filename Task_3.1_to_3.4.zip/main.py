# This is the main script for the game: Dungeons and Dragons

from warrior import Warrior
from mage import Mage
from monster import Monster
from equipment import Equipment
from random import randint



# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.


def main():
    # create objects
    w1 = Warrior("Wolf", 15, 3, 2, 0)
    m1 = Mage("Wizzard", 15, 1, 3, 0)
    mon1 = Monster("Dracula",10, 2, 1, 2)

    # display strengths of the characters
    print(f"{m1.name}'s intelligence is: {m1.intelligence}.")
    print(f"{w1.name}'s strength is: {w1.strength}.")
    print(f"{mon1.name}'s strength is: {mon1.strength}.")

    # create equipment
    e1 = Equipment("Fire", 2, 1, 1)
    e2 = Equipment("Magic", 1, 1, 1)

    # calling equipment method
    w1.equip(e1)
    m1.equip(e2)

    # display strengths of the characters
    print("\n", 10 * "-", "After the equipment have been added", 10 * "-")
    print(f"{m1.name}'s intelligence is: {m1.intelligence}.")
    print(f"{w1.name}'s strength is: {w1.strength}.")
    print(f"{mon1.name}'s strength is: {mon1.strength}.")

    # the battle starts
    print("\n", 20 * "*", "Battle starts!!!", 20 * "*")
    battle(w1, m1)

    # display heath (hp) of the characters after the battle
    print(f"{m1.name}'s health is: {m1.hp}.")
    print(f"{w1.name}'s health is: {w1.hp}.")
    print(f"{mon1.name}'s health is: {mon1.hp}.")

    # display GAMEOVER
    print("\n", 20 * "*", "GAMEOVER!!!", 20 * "*")



def battle(ch1, ch2):
    turn = randint(1,2)
    counter = 0
    while ch1.hp > 0 and ch2.hp > 0:

        if turn % 2 == 0:
            #display turn
            counter += 1
            print(f" This is turn {counter}!")
            damage = ch1.attack()

            #display damage
            print(f"Damage to be done to {ch2.name} at the level: {damage}")
            ch2.defend(damage)

            # display health (hp) of the attacked character
            print(f"{ch2.name}'s health is: {ch2.hp}.")
        else:
            counter += 1
            print(f" This is turn {counter}!")
            damage = ch2.attack()
            print(f"Damage to be done to {ch1.name} at the level: {damage}")
            ch1.defend(damage)

            # display health (hp) of the attacked character
            print(f"{ch1.name}'s health is: {ch1.hp}.")
        turn += 1
        print(50 * "-")

    if ch1.hp > ch2.hp:
        print(f"The winner is {ch1.name} ")
    else:
        print(f"The winner is {ch2.name} ")



if __name__ == '__main__':
    main()

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
