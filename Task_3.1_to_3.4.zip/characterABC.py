from abc import ABC, abstractmethod
from equipment import Equipment


class CharacterABC(ABC):
    def __init__(self, name, hp, strength, intelligence):
        self.name = name
        self.hp = hp
        self.strength = strength
        self.intelligence = intelligence


    # getters
    def getName(self):
        return self.name

    def getHp(self):
        return self.hp

    def getStrength(self):
        return self.strength

    def getIntelligence(self):
        return self.intelligence

    # setters

    def setName(self, name):
        self.name = name

    def setHp(self, hp):
        self.hp = hp

    def setStrength(self, strength):
        self.strength = strength

    def setIntelligence(self, intelligence):
        self.intelligence = intelligence

    # methods
    @abstractmethod
    def attack(self):
        pass

    @abstractmethod
    def defend(self, damage):
        pass

    def equip(self, equipment):
        self.hp += equipment.bonus_hp
        self.strength += equipment.bonus_strength
        self.intelligence += equipment.bonus_intelligence
