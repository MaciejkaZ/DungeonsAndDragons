class Item:
    def __init__(self, name, effect):
        self.name = name
        self.effect = effect # !!! TBC, it is supposed to be a reference to a function