from characterABC import CharacterABC
from random import random

class Mage(CharacterABC):

    def __init__(self, name, hp, strength, intelligence, damage):
        super().__init__(name, hp, strength, intelligence)
        self.damage = damage

    def attack(self):
        if random() < 0.2:
            return 2 * 3 * self.intelligence
        return 3 * self.intelligence

    def defend(self, damage):
        damage = damage - self.intelligence
        if damage > 0:
            hp = self.hp - damage
            if hp >= 0:
                self.hp = hp
            else:
                self.hp = 0
        else:
            return

    def specialAbility(self):
        self.intelligence *= 5
