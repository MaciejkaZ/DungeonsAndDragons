from abc import ABC, abstractmethod

class CharacterABC(ABC):
    def __init__(self, name, hp, strength, intelligence, inventory = []):
        self.name = name
        self.hp = hp
        self.strength = strength
        self.intelligence = intelligence
        self.inventory = inventory


    # getters
    def getName(self):
        return self.name

    def getHp(self):
        return self.hp

    def getStrength(self):
        return self.strength

    def getIntelligence(self):
        return self.intelligence

    def getInventory(self):
        names = [o.name for o in self.inventory]
        return ", ".join(names)

    # setters

    def setName(self, name):
        self.name = name

    def setHp(self, hp):
        self.hp = hp

    def setStrength(self, strength):
        self.strength = strength

    def setIntelligence(self, intelligence):
        self.intelligence = intelligence

    def setInventory(self, item):
        self.inventory.append(item)

    # methods
    @abstractmethod
    def attack(self):
        pass

    @abstractmethod
    def defend(self, damage):
        pass

    def equip(self, equipment):
        self.hp += equipment.bonus_hp
        self.strength += equipment.bonus_strength
        self.intelligence += equipment.bonus_intelligence

    def addItem(self, item):
        self.inventory.append(item)

    def useItem(self, itemName):
        done = False
        i=0
        while not done and i in range(len(self.inventory)):
            if self.inventory[i].name == itemName:
                self.inventory[i].effect()
                self.inventory.pop(i)
                done = True
            i += 1
        return
